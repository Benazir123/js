<template>
  <div class="card mb-4">
    <div class="card-header pb-0 d-flex justify-content-between">
      <h6>System Info</h6>
      <!-- <button class="btn btn-dark btn-sm m-3 rounded">Add System Details</button> -->
      <!-- Button trigger modal -->
<button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Add System Details
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-uppercase" id="exampleModalLabel">Add System Details</h5>
        <button type="button" class="btn-close bg-secondary" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form>
         <div class="mb-3">
            <label for="id" class="col-form-label">ID:</label>
            <input type="text" class="form-control" id="id" placeholder="Enter Your ID">
          </div>
          <div class="mb-3">
            <label for="employee-id" class="col-form-label">Employee ID:</label>
            <input type="text" class="form-control" id="employee-id" placeholder="Enter Your Employee ID">
          </div>
          <div class="mb-3">
            <label for="system-modalId" class="col-form-label">System Modal ID:</label>
            <input type="text" class="form-control" id="system-modalId" placeholder="Enter Your System Modal ID"/>
          </div>
          <div class="mb-3">
            <label for="system-os" class="col-form-label">System OS:</label>
            <input type="text" class="form-control" id="system-os" placeholder="Enter Your System OS"/>
          </div>
            <div class="mb-3">
            <label for="system-memory" class="col-form-label">System Memory:</label>
            <input type="text" class="form-control" id="system-memory" placeholder="Enter Your System Memory"/>
          </div>
          <div class="mb-3">
            <label for="system-ram" class="col-form-label">System RAM:</label>
            <input type="text" class="form-control" id="system-ram" placeholder="Enter Your System RAM"/>
          </div>
          <div class="mb-3">
            <label for="system-chip" class="col-form-label">System Chip:</label>
            <input type="text" class="form-control" id="system-type" placeholder="Enter Your System Chip"/>
          </div>
          <div class="mb-3">
            <label for="employee-serialNo" class="col-form-label">Employee Serial No:</label>
            <input type="text" class="form-control" id="system-type" placeholder="Enter Your Employee Serial No"/>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success">Save</button>
      </div>  
    </div>
  </div>
</div>
<!-- Modal end-->
    </div>
    <div class="card-body px-0 pt-0 pb-2">
      <div class="table-responsive p-0">
        <table class="table align-items-center mb-0">
          <thead>
            <tr>
              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">ID</th>
              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Employee ID</th>
              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">System Modal ID</th>
              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">System OS</th>
              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">System Memory</th>
              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">System RAM</th>
              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">System Chip</th>
              <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Employee serial No</th>


              <!-- <th
                class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2"
              >System ID</th>
              <th
                class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"
              >System Type</th>
              <th
                class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"
              >System's property</th> -->
              <!-- <th class="text-secondary opacity-7"></th> -->
               <th
                class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-0"
              >Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="data in listArray" :key="data.id">
              <td>{{data.id}}</td>
              <td class="ps-5">{{data.emp_id}}</td>
              <td class="ps-5">{{data.emp_sys_model_id}}</td>
              <td class="ps-4">{{data.emp_sys_os}}</td>
              <td class="ps-5">{{data.emp_sys_memory}}</td>
              <td class="ps-5">{{data.emp_sys_ram}}</td>
              <td class="ps-4">{{data.emp_sys_chip}}</td>
              <td class="ps-4">{{data.emp_serial_no}}</td>

              <!-- <td> -->
                <!-- <div class="d-flex px-2 py-1">
                  <div>
                    <vsud-avatar :img="img1" size="sm" border-radius="lg" class="me-3" alt="user1" />
                  </div>
                  <div class="d-flex flex-column justify-content-center">
                    <h6 class="mb-0 text-sm">John Michael</h6>
                    <p class="text-xs text-secondary mb-0">john@creative-tim.com</p>
                  </div>
                </div> -->
              <!-- </td> -->
              <!-- <td>
                  
              </td> -->
              <!-- <td> -->
                <!-- <p class="text-xs font-weight-bold mb-0">Manager</p>
                <p class="text-xs text-secondary mb-0">Organization</p> -->
              <!-- </td> -->
              <!-- <td class="align-middle text-center text-sm"> -->
                <!-- <vsud-badge color="success" variant="gradient" size="sm">Online</vsud-badge> -->
              <!-- </td> -->
              <!-- <td class="align-middle text-center"> -->
                <!-- <span class="text-secondary text-xs font-weight-bold">23/04/18</span> -->
              <!-- </td> -->
              <td>
                <a
                  href="javascript:;"
                  class="text-secondary font-weight-bold text-xs"
                  data-toggle="tooltip"
                  data-original-title="Edit user"
                >Edit</a>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from '@vue/reactivity';
import myService from '../../services/myService';
import { onMounted } from '@vue/runtime-core';
export default {
  setup(){
     var list = new Array();
     const listArray = ref([])
     async function listSystems(formData){
       list = await myService.systemlist(formData)
       listArray.value = list.data
       console.log("Get SystemInfo=>", listArray.value)
     }
     onMounted(listSystems)
     return{
       list,
       listArray,
       listSystems
     }
  }
  
}
</script>
