importScripts("/newclientadmin/precache-manifest.8379a7aca72c9d1ab9e08aa59b54e44e.js", "https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js");


workbox.core.skipWaiting();
workbox.core.clientsClaim();
self.__precacheManifest = [].concat(self.__precacheManifest || [])

